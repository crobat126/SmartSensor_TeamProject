/**
 * Kakao Android SDK 내부에서 사용하는 패키지로 향후 안내 없이 변경 또는 제거될 수 있습니다.
 */
package com.kakao.util.exception;
