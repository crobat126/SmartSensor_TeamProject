package com.kakao.network;

/**
 * @author kevin.kang. Created on 2017. 3. 20..
 */

public class StringSet {
    public static final String code = "code";
    public static final String msg = "msg";
    public static final String error = "error";
    public static final String error_description = "error_description";
    public static final String SECURE_RESOURCE = "secure_resource";
    public static final String FILE = "file";
    public static final String IMAGE_URL = "image_url";
}
