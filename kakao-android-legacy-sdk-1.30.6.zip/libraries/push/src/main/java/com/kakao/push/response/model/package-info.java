/**
 * Provides response models for Push API.
 */
package com.kakao.push.response.model;