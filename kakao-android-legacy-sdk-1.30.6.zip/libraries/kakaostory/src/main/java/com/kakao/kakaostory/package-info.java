/**
 * Provide KakaoStory API.
 */
package com.kakao.kakaostory;